Each week is encapsulated in each folder.
For each folder, there is a word document summarizing progress for that week.
To get more details, refer to the git repo:

https://github.com/stevenoh93/PortableHolography.git

In each word document, references to files are labeled by number, 
which match the number prefixing the names of each files in the same directory.